
# Website Navigation

---

| ![Logo](logo.png) (200px x 150px) | [Home](#) | [About Us](#) | [Exam Boards](#) | [Subjects](#) | [Home School](#) | [Career](#) | [Contact Us](#) | [Apply Now](#) (Button) |
|---|---|---|---|---|---|---|---|---|


# Website Navigation (Mobile View)

---

## Top-Center

- ![Logo](logo.png) (200px x 150px)
- [Apply Now](#) (Button)

## Hamburger Menu (Top-Left)

- [Home](#)
- [About Us](#)
- [Exam Boards](#)
- [Subjects](#)
- [Home School](#)
- [Career](#)
- [Contact Us](#)
