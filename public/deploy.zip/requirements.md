# Become a Tutor 

## Tutor vacancy only for Srilankans

- Full Name
- Email
- Phone Number
- Age
- Years of Experience in Teaching 
- All educational qualifications
- Subjects you can teach

Fluency in English - This should be dropdown with the following options - can choose only one option

- Fluent
- Good
- Average
- Poor

IT Skills - This should be dropdown with the following options - can choose only one option

- Excellent
- Good
- Average
- Poor

Have you got your own laptop, Microphone, Digital Writing Pad and a stable internet connection - This should be dropdown with the following options - can choose only one option

 - Yes
 - No

- Curriculum you can teach - This should be dropdown with the following options - can choose multiple options
  - Edexcel
  - Cambridge
  - AQA
  - OCR A & OCR B
  - IB
  - OSSD
  - VCE

- Grade you can teach - This should be dropdown with the following options - can choose multiple options
    - Year 7
    - Year 8
    - Year 9
    - Year 10
    - Year 11
    - Year 12

- Preferred time to teach - This should be dropdown with the following options - can choose multiple options
    - Weekdays
    - Weekends
    - Weekdays and Weekends

- Preferred time to teach - This should be dropdown with the following options - can choose multiple options
    - 9am - 12pm
    - 12pm - 3pm
    - 3pm - 6pm
    - 6pm - 9pm

Part-time or Full-time - This should be dropdown with the following options - can choose only one option
    - Part-time
    - Full-time

if Part time - are you able to commit 3 hours per day - This should be dropdown with the following options - can choose only one option

  - Yes
  - No

if Full time - are you able to commit 6 hours per day - This should be dropdown with the following options - can choose only one option
    
  - Yes
  - No

Option to upload CV - This should be a file upload option PDF/DOCX

If your CV is sort listed are you available for an over the phone interview between 9 AM - 5 PM from Monday to Friday - This should be dropdown with the following options - can choose only one option

  - Yes
  - No 







